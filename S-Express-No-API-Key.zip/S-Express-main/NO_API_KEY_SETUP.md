# S-Express — No AI API Key Mode

This version is designed so the application does not require an AI API key just to start.

- AI API credentials are optional.
- Do not commit `.env` or secret values to GitHub.
- On Vercel, deploy the project normally.
- If an AI endpoint exists, it should gracefully report that AI is not configured rather than crashing.

Required external services such as MongoDB may still need their own environment variable if the application uses the database.
