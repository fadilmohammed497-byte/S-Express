const jwt = require('jsonwebtoken');
const User = require('../models/User');

function signToken(user) {
  if (!process.env.JWT_SECRET) throw new Error('JWT_SECRET is not configured');
  return jwt.sign({ id: user._id.toString(), userType: user.userType }, process.env.JWT_SECRET, { expiresIn: '7d' });
}

async function requireAuth(req, res, next) {
  try {
    const header = req.headers.authorization || '';
    const token = header.startsWith('Bearer ') ? header.slice(7) : null;
    if (!token) return res.status(401).json({ success: false, message: 'Authentication required' });
    if (!process.env.JWT_SECRET) return res.status(500).json({ success: false, message: 'JWT_SECRET is not configured' });
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(decoded.id).select('-password');
    if (!user || !user.isActive) return res.status(401).json({ success: false, message: 'Invalid authentication' });
    req.user = user;
    next();
  } catch (err) {
    return res.status(401).json({ success: false, message: 'Invalid or expired token' });
  }
}

function allow(...types) {
  return (req, res, next) => {
    if (!req.user || !types.includes(req.user.userType)) return res.status(403).json({ success: false, message: 'Forbidden' });
    next();
  };
}

module.exports = { signToken, requireAuth, allow };
