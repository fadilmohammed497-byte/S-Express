require('dotenv').config();
const { app } = require('./app');
const { createServer } = require('http');
const { Server } = require('socket.io');

const PORT = process.env.PORT || 5000;
const httpServer = createServer(app);
const io = new Server(httpServer, {
  cors: { origin: process.env.FRONTEND_URL || '*', methods: ['GET', 'POST'] }
});

io.on('connection', (socket) => {
  socket.on('join-delivery', (orderId) => socket.join(`delivery-${orderId}`));
  socket.on('leave-delivery', (orderId) => socket.leave(`delivery-${orderId}`));
});

httpServer.listen(PORT, () => {
  console.log(`S-Express server running on port ${PORT}`);
});

module.exports = { app, io };
