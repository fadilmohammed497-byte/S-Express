const router=require('express').Router();const User=require('../models/User');const {requireAuth,allow}=require('../middleware/auth');
router.get('/me',requireAuth,allow('customer'),async(req,res)=>res.json({success:true,customer:req.user}));
router.patch('/me',requireAuth,async(req,res,next)=>{try{const allowed=['firstName','lastName','phone','address','profilePicture'];for(const k of allowed)if(req.body[k]!==undefined)req.user[k]=req.body[k];await req.user.save();res.json({success:true,customer:req.user});}catch(e){next(e)}});module.exports=router;
