const router = require('express').Router();
const Restaurant = require('../models/Restaurant');
const { requireAuth, allow } = require('../middleware/auth');
router.get('/', async (req,res,next)=>{try{const q={isActive:true}; if(req.query.city) q['address.city']=req.query.city; if(req.query.search) q.restaurantName={$regex:req.query.search,$options:'i'}; res.json({success:true,restaurants:await Restaurant.find(q).sort({createdAt:-1})});}catch(e){next(e)}});
router.get('/:id', async(req,res,next)=>{try{const r=await Restaurant.findById(req.params.id); if(!r)return res.status(404).json({success:false,message:'Restaurant not found'}); res.json({success:true,restaurant:r});}catch(e){next(e)}});
router.post('/',requireAuth,allow('restaurant','admin'),async(req,res,next)=>{try{const r=await Restaurant.create({...req.body,owner:req.user._id});res.status(201).json({success:true,restaurant:r});}catch(e){next(e)}});
router.put('/:id',requireAuth,async(req,res,next)=>{try{const r=await Restaurant.findById(req.params.id);if(!r)return res.status(404).json({success:false,message:'Restaurant not found'});if(req.user.userType!=='admin' && String(r.owner)!==String(req.user._id))return res.status(403).json({success:false,message:'Forbidden'});Object.assign(r,req.body);r.updatedAt=new Date();await r.save();res.json({success:true,restaurant:r});}catch(e){next(e)}});
module.exports=router;
