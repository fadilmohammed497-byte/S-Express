const router = require('express').Router();
const User = require('../models/User');
const { signToken, requireAuth } = require('../middleware/auth');

router.post('/register', async (req, res, next) => {
  try {
    const { firstName, lastName, email, phone, password, userType = 'customer' } = req.body;
    if (!firstName || !lastName || !email || !phone || !password) return res.status(400).json({ success: false, message: 'firstName, lastName, email, phone and password are required' });
    if (password.length < 6) return res.status(400).json({ success: false, message: 'Password must be at least 6 characters' });
    const normalized = email.toLowerCase().trim();
    if (await User.findOne({ email: normalized })) return res.status(409).json({ success: false, message: 'Email already registered' });
    const user = await User.create({ firstName, lastName, email: normalized, phone, password, userType });
    res.status(201).json({ success: true, token: signToken(user), user: user.toObject({ transform: (_, ret) => { delete ret.password; return ret; } }) });
  } catch (err) { next(err); }
});

router.post('/login', async (req, res, next) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email: String(email || '').toLowerCase().trim() });
    if (!user || !(await user.comparePassword(password || ''))) return res.status(401).json({ success: false, message: 'Invalid email or password' });
    res.json({ success: true, token: signToken(user), user: user.toObject({ transform: (_, ret) => { delete ret.password; return ret; } }) });
  } catch (err) { next(err); }
});

router.get('/me', requireAuth, (req, res) => res.json({ success: true, user: req.user }));
module.exports = router;
